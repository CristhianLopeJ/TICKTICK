import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Main {

    private WebDriver driver = null;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "E:\\test TICKTICK002\\src\\test\\resources\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://ticktick.com/");
    }
    // LOGIN PAGE
    String signInButton = "//div[@class='navRow_236y3 container']//a[normalize-space()='Sign In']";
    String idEmail = "//input[@id='emailOrPhone']";
    String idPassword = "//input[@id='password']";
    String buttonSignIn = "//button[@class='button__3eXSs '] ";
    //MainMenu
    String clickListIcon = "(//*[local-name()='svg'])[19]";
    String projectName = "//input[@id='edit-project-name']";
    String clickSaveButton = "//button[contains(text(),'Save')]";
    //EDIT PROJECT
    String editListCreated = "//p[contains(text(),'Tarea001')]/following-sibling::div/child::div//*[local-name()='svg' and @class='icon-more-for-folder w-[18px] h-[18px] hover:text-sidebar-color text-sidebar-color-40 ']";


    @Test
    public void testing() throws InterruptedException {
        driver.findElement(By.xpath(signInButton)).click();
        driver.findElement(By.xpath(idEmail)).sendKeys("digitaltest71@gmail.com");
        driver.findElement(By.xpath(idPassword)).sendKeys("Password1!");
        driver.findElement(By.xpath(buttonSignIn)).click();
        Thread.sleep(7000);
        //MainMenu
        driver.findElement(By.xpath(clickListIcon)).click();
        driver.findElement(By.xpath(projectName)).sendKeys("Tarea001");
        driver.findElement(By.xpath(clickSaveButton)).click();
        //EDIT PROJECT
        driver.findElement(By.xpath(editListCreated)).click();
    }

}
